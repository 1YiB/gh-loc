# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['fire>=0.5.0,<0.6.0',
 'httpx>=0.23.1,<0.24.0',
 'ndicts>=0.1.0,<0.2.0',
 'ratelimiter>=1.2.0.post0,<2.0.0',
 'rich>=12.6.0,<13.0.0',
 'tomli>=2.0.1,<3.0.0']

entry_points = \
{'console_scripts': ['gh-loc = src.main:app']}

setup_kwargs = {
    'name': 'gh-loc',
    'version': '0.1.0',
    'description': '',
    'long_description': '<h3 align="center">\n    gh-loc\n</h3>\n<h6 align="center">\n    <a href="#install">Install</a>\n    ·\n    <a href="#config">Config</a>\n    ·\n    <a href="#usage">Usage</a>\n</h6>\n\n### Install\n\n<br />\n\n> pre-requisite: `python=^3.10` `pip` `conda(optional)` `gh-account` `git`\n\n- clone git repo\n\n```\n$ git clone https://github.com/1YiB/gh-loc.git\n```\n\n- install `*.whl` file\n\n```\n$ cd gh-loc/dist\n$ pip install <name of file>\n```\n\n- check if installed\n\n```\n\n$ which gh-loc # bash\n$ where gh-loc # cmd\n$ gcm gh-loc   # pwsh\n```\n\n### Config\n\n- gh-loc must first be configured before being used.\n\n- it can be configured using the `~/.config/gh-loc/config.toml` file\n\n- the format is given below:\n\n```toml\n# ~/.config/gh-loc/config.toml\n\n[gen]\n# length of generate user names\nlength = 3\n\n[api]\n\n\n[api.rest]\n\n# api url \nbase_url = "https://api.github.com/users/"\n# your username\ngh_username = ""\n# your github token (github.com/settings/tokens)\ngh_token = ""\n\n# file where available names are written\nlog_file = "names.log"\n\n[api.site]\n\n# advanced feature , does not work as of now\nbase_url = "https://github.com/signup_check/username"\ncookies = {}\nheaders = {}\ncontent = ""\n\ndata_file = "names.log" \nlog_file = "verified_names.log"\n```\n\n### Usage\n\n- Rest\n    - official github api which requires token\n\n``` \n$ gh-loc rest <number of usernames to generate>\n```\n\n- Site\n    - unofficial github api which requires auth_token from website \n    -  does not work as of now\n```\n$ gh-loc site \n```\n\n- Help Page\n\n```\n$ gh-loc --help\n```',
    'author': '1YiB',
    'author_email': '1yib@proton.me',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
